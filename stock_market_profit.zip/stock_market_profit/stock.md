# Stock Analyzer Code Guide

This document explains every part of `stock_analyser.py`. The program is a small interactive planner: it accepts cluster resources and workload size, calculates reasonable Spark settings, and prints a `spark-submit` command.

## 1. File Header

```python
# ============================================================
# Spark Configuration Planner
# ============================================================
```

These are comments. Python ignores them. They identify the purpose of the file as a Spark configuration planner.

## 2. `get_int`

```python
def get_int(message, minimum=1):
```

Defines a function named `get_int`.

- `message` is the text shown to the user.
- `minimum=1` means the default smallest accepted value is `1`.
- The function is reusable for any integer input that must be positive or greater.

```python
    while True:
```

Starts an infinite loop. The loop continues until the user enters a valid value.

```python
        try:
            value = int(input(message))
```

1. `input(message)` displays the prompt and reads text from the user.
2. `int(...)` converts that text into an integer.
3. The result is stored in `value`.
4. If the text is not a valid integer, Python raises `ValueError`.

```python
            if value >= minimum:
                return value
```

Checks that the entered number is large enough. When valid, `return` sends the number back to the caller and stops the loop.

```python
            print(f"Value must be greater than or equal to {minimum}.")
```

Displays an error when the number is too small. The `f` before the string allows the `minimum` value to be inserted into the message.

```python
        except ValueError:
            print("Please enter a valid integer.")
```

Handles invalid text such as `abc` or `2.5` without crashing the program. The loop then asks again.

## 3. `get_float`

```python
def get_float(message, minimum=0.1):
```

Defines a function for reading decimal numbers. The default minimum is `0.1`, which is suitable for a data size in gigabytes.

```python
    while True:
        try:
            value = float(input(message))
```

Repeats the input until it is valid, then converts the entered text into a Python `float`.

```python
            if value >= minimum:
                return value
```

Returns the number only when it meets the minimum requirement.

```python
            print(f"Value must be greater than or equal to {minimum}.")
```

Reports a value that is too small.

```python
        except ValueError:
            print("Please enter a valid number.")
```

Handles text that cannot be converted to a decimal number.

## 4. `calculate_configuration`

```python
def calculate_configuration(
    data_size_gb,
    cluster_cpu_cores,
    cluster_memory_gb,
    workload
):
```

Defines the main calculation function. It receives:

- `data_size_gb`: input data size in gigabytes.
- `cluster_cpu_cores`: total CPU cores available.
- `cluster_memory_gb`: total memory available in gigabytes.
- `workload`: one of `Light`, `Medium`, or `Heavy`.

The function returns a dictionary containing the calculated Spark settings.

### Driver cores

```python
driver_cores = min(2, cluster_cpu_cores)
```

Assigns up to two CPU cores to the Spark driver. If the cluster has only one core, it uses one instead of requesting more cores than exist.

### Driver memory

```python
driver_memory = max(2, min(8, round(cluster_memory_gb * 0.1)))
```

Reserves about ten percent of cluster memory for the driver.

The nested functions apply limits:

1. `cluster_memory_gb * 0.1` calculates ten percent.
2. `round(...)` removes the decimal portion.
3. `min(8, ...)` caps driver memory at `8` GB.
4. `max(2, ...)` guarantees at least `2` GB.

For example, with `8` GB total memory, ten percent is less than `2`, so the driver receives `2` GB.

### Workload-based executor cores

```python
executor_cores = {"Light": 2, "Medium": 3, "Heavy": 4}[workload]
```

Uses a dictionary to map workload names to executor CPU sizes:

- `Light` gets `2` cores.
- `Medium` gets `3` cores.
- `Heavy` gets `4` cores.

The value is looked up using the selected `workload` string.

### Cores available to executors

```python
available_cores = max(1, cluster_cpu_cores - driver_cores)
```

Subtracts the driver cores from the total cluster cores. The `max(1, ...)` prevents the result from becoming zero or negative.

### Prevent oversized executors

```python
executor_cores = min(executor_cores, available_cores)
```

If the requested executor size is larger than the available CPU capacity, this reduces it to a valid size.

### Number of executors

```python
executors = max(1, available_cores // executor_cores)
```

Uses integer division, `//`, to calculate how many executors fit into the available cores. At least one executor is always requested.

For example:

```text
Available cores = 6
Executor cores  = 2
Executors       = 6 // 2 = 3
```

### Executor memory

```python
executor_memory = max(2, min(16, (cluster_memory_gb - driver_memory) // executors))
```

Distributes memory left after the driver allocation across the executors.

The limits work as follows:

1. `cluster_memory_gb - driver_memory` removes the driver allocation.
2. `// executors` divides the remaining memory evenly.
3. `min(16, ...)` caps each executor at `16` GB.
4. `max(2, ...)` guarantees at least `2` GB per executor.

### Total executor cores

```python
total_executor_cores = executors * executor_cores
```

Calculates the total CPU capacity available to executor tasks.

### Returned configuration

```python
return {
    "driver_cores": driver_cores,
    "driver_memory": driver_memory,
    "executors": executors,
    "executor_cores": executor_cores,
    "executor_memory": executor_memory,
    "input_partitions": max(1, round(data_size_gb / 0.128)),
    "shuffle_partitions": max(50, total_executor_cores * 10),
}
```

Returns a dictionary so the next function can access each setting by name.

The last two values are partition estimates:

```python
"input_partitions": max(1, round(data_size_gb / 0.128))
```

Estimates one input partition per approximately `0.128` GB, or about `128` MB. It rounds the result and ensures at least one partition.

```python
"shuffle_partitions": max(50, total_executor_cores * 10)
```

Estimates ten shuffle partitions per executor core, with a minimum of `50`. Shuffle partitions are used by Spark operations such as `groupBy`, `join`, and aggregations.

## 5. `display_configuration`

```python
def display_configuration(config):
```

Defines a function that prints the calculated settings and a ready-to-use Spark command.

```python
    print("\nSpark configuration")
    print("-------------------")
```

Prints a heading. `\n` inserts a blank line before the heading.

```python
    for name, value in config.items():
        print(f"{name.replace('_', ' ').title():22}: {value}")
```

Loops through every key and value in the configuration dictionary.

- `config.items()` returns each key-value pair.
- `replace('_', ' ')` makes names easier to read.
- `title()` capitalizes each word.
- `:22` reserves a fixed-width display area so the colons line up.

For example, `driver_cores` is displayed as `Driver Cores`.

### Spark submit command

```python
    print("\nSpark submit command")
    print("--------------------")
```

Prints a second heading for the generated command.

```python
    print(
        "spark-submit --master yarn --deploy-mode cluster "
```

Starts the command. It tells Spark to use YARN and run in cluster deploy mode.

```python
        f"--num-executors {config['executors']} "
        f"--executor-cores {config['executor_cores']} "
        f"--executor-memory {config['executor_memory']}G "
```

Adds executor settings from the dictionary:

- Number of executors.
- CPU cores per executor.
- Memory per executor.

The `G` suffix means gigabytes.

```python
        f"--driver-cores {config['driver_cores']} "
        f"--driver-memory {config['driver_memory']}G "
```

Adds the driver CPU and memory settings.

```python
        f"--conf spark.sql.shuffle.partitions={config['shuffle_partitions']} "
```

Sets Spark SQL's default shuffle partition count to the calculated value.

```python
        "--conf spark.sql.adaptive.enabled=true stock_analysis.py"
    )
```

Enables Adaptive Query Execution and specifies the Spark application file to submit.

## 6. `main`

```python
def main():
```

Defines the function that controls the user-facing program flow.

```python
data_size_gb = get_float("Input data size (GB): ")
```

Requests the input dataset size and validates it as a decimal number.

```python
cpu_cores = get_int("Available CPU cores: ")
```

Requests the number of available CPU cores and validates it as an integer.

```python
memory_gb = get_int("Available memory (GB): ")
```

Requests the available cluster memory in gigabytes.

```python
choice = input("Workload [1=Light, 2=Medium, 3=Heavy]: ").strip()
```

Reads the workload selection. `strip()` removes extra spaces before and after the input.

```python
workload = {"1": "Light", "2": "Medium", "3": "Heavy"}.get(choice, "Medium")
```

Converts the numeric selection into a workload name. If the user enters anything else, the program defaults to `Medium`.

```python
display_configuration(calculate_configuration(data_size_gb, cpu_cores, memory_gb, workload))
```

Performs two operations in one line:

1. Calculates the configuration.
2. Sends the returned dictionary to `display_configuration` for printing.

## 7. Program Entry Point

```python
if __name__ == "__main__":
    main()
```

`__name__` is set to `"__main__"` when this file is run directly with Python. In that case, the program calls `main()`.

If another Python file imports `stock_analyser.py`, this block does not run automatically. That allows the functions to be reused without starting the interactive prompts.

## 8. Example Run

Example inputs:

```text
Input data size (GB): 1
Available CPU cores: 4
Available memory (GB): 8
Workload [1=Light, 2=Medium, 3=Heavy]: 2
```

The important calculated values are:

```text
Driver cores       : 2
Driver memory      : 2 GB
Executors          : 1
Executor cores     : 2
Executor memory    : 6 GB
Input partitions   : 8
Shuffle partitions : 50
```

Run the planner with:

```powershell
py stock_analyser.py
```

This planner only generates configuration guidance. The Spark UI at `http://localhost:4040` belongs to the Spark application in `app.py`, not to this planner.

## 9. How to Choose the Data-Size Input

When the program asks for `Input data size (GB)`, enter the estimated total amount of data that Spark will process, in gigabytes.

For the current project, the file size is:

```text
stock_transactions_large.csv = 3.73 MB = approximately 0.0036 GB
```

The planner currently accepts a minimum of `0.1 GB`, so use this value for the current practice dataset:

```text
0.1
```

For larger workloads, convert the total input size to gigabytes:

```text
data_size_gb = total_file_size_in_bytes / 1,073,741,824
```

Useful conversions are:

```text
100 MB = 0.1 GB
1 GB   = 1
10 GB  = 10
500 GB = 500
2 TB   = 2048 GB
```

Include every file Spark will read, including all CSV, JSON, or Parquet files and all partitions in the processing batch. For production planning, include expected growth and peak volume rather than using only today's file size.

Example:

```text
Current data:    80 GB
Expected growth: 25%
Peak input:      80 * 1.25 = 100 GB
```

In this case, enter `100`.

The value is used to estimate input partitions:

```python
input_partitions = max(1, round(data_size_gb / 0.128))
```

The calculation assumes approximately `128 MB` per input partition. For example, `10 GB` produces approximately `78` input partitions.

Data size is only one planning input:

- CPU cores determine how many tasks can run in parallel.
- Memory determines driver and executor sizing.
- Workload estimates how intensive the Spark job is.
- Shuffle partitions should be reviewed after a test run using the Spark UI.
