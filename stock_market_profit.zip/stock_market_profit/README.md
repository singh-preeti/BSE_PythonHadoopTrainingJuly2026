# Beginner Stock Profit Spark App

A small PySpark application for practicing stock profit calculations and Spark performance tuning. It runs locally in PyCharm and reads the included 100,000-row `stock_transactions_large.csv` file.

## Setup in PyCharm

1. Open this folder as a project.
2. Create a Python virtual environment when PyCharm asks.
3. Open the PyCharm Terminal and install the dependency:

```text
pip install -r requirements.txt
```

4. Right-click `app.py` and choose **Run 'app'**.

To inspect the Spark UI, open PyCharm's **Run/Debug Configurations**, add `--keep-ui` to **Parameters**, and run again. While the program is waiting at the final prompt, open `http://localhost:4040` in your browser. Check **Jobs**, **Stages**, **Storage**, and **SQL/DataFrame** tabs. Return to PyCharm and press Enter when finished.

PySpark needs Java. If Spark reports that Java is missing, install a JDK such as Java 17 and set `JAVA_HOME` to its folder.

## What the app demonstrates

- Profit formula: `(sell_price - buy_price) * quantity`
- Memory and shuffle tuning with `spark.sql.shuffle.partitions`
- Caching with `MEMORY_AND_DISK` and `unpersist()`
- Debugging with `explain("formatted")` and the Spark UI
- A hands-on exercise that finds the most profitable company

The detailed Spark UI walkthrough is in [SPARK_UI_GUIDE.md](SPARK_UI_GUIDE.md).

## Hands-on exercise

1. Change a `sell_price` in `stock_transactions_large.csv`.
2. Run `app.py` again.
3. Observe how the winning company changes.
4. Compare the normal aggregation with the **Slow-job experiment** in Spark UI.
5. Add a `total_volume` calculation and find the busiest symbol.

For a larger dataset, increase the input rows and compare the runtime with and without `persist()`. While Spark is running, the Spark UI is usually available at `http://localhost:4040`.

To recreate the deterministic 100,000-row CSV, run:

```text
python generate_stock_data.py
```
