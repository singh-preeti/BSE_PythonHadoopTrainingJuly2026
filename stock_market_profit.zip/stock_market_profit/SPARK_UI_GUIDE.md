# Spark UI: Beginner Step-by-Step Guide

This guide uses `app.py` and `stock_transactions_large.csv`.

## 1. Start the application

Open the PyCharm Terminal in this project folder and run:

```text
python app.py --keep-ui
```

Wait until the program prints:

```text
Spark UI is running at http://localhost:4040
```

Leave that terminal window open. Open `http://localhost:4040` in Chrome, Edge, or the VS Code browser.

If port 4040 is busy, Spark prints another port such as 4041. Open the port shown in the terminal.

## 2. Understand the main tabs

### Jobs

Jobs are created by actions such as `count()` and `show()`. `explain("formatted")` only prints a plan; it does not execute the data operation by itself. The current app also runs profit aggregation, cached-data reuse, repartition analysis, stock ranking, and trading-volume analysis. Click a job to see its stages.

Look for:

- Long total duration
- A large number of stages
- Failed jobs or failed tasks
- The SQL query description

### Stages

A stage ends when Spark needs a shuffle. In this application, `groupBy("symbol")` causes an `Exchange` and creates a shuffle boundary.

Look for:

- **Input Size**: data read by the stage
- **Shuffle Read**: data received after redistribution
- **Shuffle Write**: data written for another stage
- **Task Time**: whether a few tasks are much slower than the others
- **Tasks**: whether the partition count is reasonable

A single task that is much slower than the rest often indicates data skew.

### SQL / DataFrame

Open the SQL tab and select a query. The DAG shows the operations Spark planned. Compare the normal aggregation with the explicitly repartitioned analysis in `analyze_stock_profit_by_partition()`.

Important plan words:

- `Scan`: reads the CSV
- `Project`: calculates or selects columns
- `Exchange`: shuffles data between partitions
- `HashAggregate`: performs the `groupBy` calculation

### Storage

The caching section appears after the persisted DataFrame is materialized by `count()` and reused by another action.

Check:

- Storage level: `Memory And Disk`
- Number of cached partitions
- Memory used

Caching helps when the same DataFrame is used more than once. It can waste memory when the DataFrame is used only once. The application calls `unpersist()` when finished.

### Executors

In local mode, the driver also acts as the executor. Use this tab to inspect task counts, memory, and failures.

## 3. Follow the exercise in the UI

1. Run `python app.py --keep-ui`.
2. Open **Jobs** and note the jobs created by `count()` and the different `show()` calls.
3. Open a job and follow its link to **Stages**.
4. Find the stage containing `Exchange` or shuffle read/write.
5. Open **SQL / DataFrame** and inspect the physical plan.
6. Open **Storage** and confirm the cached DataFrame.
7. Compare the normal aggregation with the **Stock Partition Analysis** section.
8. In the SQL plan, identify the explicit `Exchange` created by `repartition(200, "symbol")`.
9. Press Enter in the terminal to stop the application after reviewing the UI.

## 4. Diagnose common issues

### Problem: Too many shuffle partitions

**UI clue:** Many tasks process tiny amounts of data and most finish very quickly.

**Try:** Change `spark.sql.shuffle.partitions` in `app.py` from `4` to a value that matches the data size. For the included 100,000-row local file, `4` is a reasonable teaching value. For a much larger dataset, test a larger value.

### Problem: Too few shuffle partitions

**UI clue:** A few tasks process a large amount of data and take a long time.

**Try:** Increase `spark.sql.shuffle.partitions` and rerun. Compare shuffle read and task duration in the Stages tab.

### Problem: Data skew

**UI clue:** One task is much slower or reads much more data than the other tasks.

**Try:** Check whether one symbol has far more rows. Filter or aggregate earlier, improve the partitioning key, or use a skew-handling strategy for a large production dataset.

### Problem: Memory pressure

**UI clue:** Tasks fail, executor memory is high, or the Storage tab shows the cache does not fit.

**Try:** Select only needed columns, filter early, avoid caching unused DataFrames, use `MEMORY_AND_DISK`, and call `unpersist()` when finished.

### Problem: Slow repeated calculations

**UI clue:** The same scan appears in multiple jobs.

**Try:** In this app, `prepare_reusable_profit_data()` persists `profit_df` with `MEMORY_AND_DISK`, materializes it with `count()`, reuses it for a grouped aggregation, and then calls `unpersist()`. Confirm the cache between those actions in **Storage**.

### Problem: Driver overload

**UI clue:** The driver becomes slow or memory usage grows after collecting results.

**Try:** Do not use `collect()` on a large DataFrame. Prefer `show()`, `write`, or an aggregation that returns a small result.

### Problem: UI does not load

**Check these items in order:**

1. The terminal still shows the `Spark UI is running` prompt.
2. The address is exactly `http://localhost:4040`.
3. If Spark reported another port, use that port.
4. Refresh the browser page.
5. Check that no firewall or proxy is blocking local addresses.
6. Confirm the endpoint from PowerShell:

```powershell
Invoke-WebRequest http://localhost:4040 -UseBasicParsing
```

An `HTTP 200` response means the Spark UI server is responding.

## 5. What to record during tuning

For each change, write down:

- Configuration value changed
- Job and stage duration
- Number of tasks
- Shuffle read and shuffle write
- Whether any task was noticeably slower
- Whether the result stayed the same

Only keep a tuning change when it improves runtime or resource use without changing the result.
