
# ============================================================
# Spark Configuration Planner
# ============================================================

def get_int(message, minimum=1):
    """Read and validate an integer value."""

    while True:
        try:
            value = int(input(message))

            if value >= minimum:
                return value

            print(f"Value must be greater than or equal to {minimum}.")

        except ValueError:
            print("Please enter a valid integer.")


def get_float(message, minimum=0.1):
    """Read and validate a numeric value."""

    while True:
        try:
            value = float(input(message))

            if value >= minimum:
                return value

            print(f"Value must be greater than or equal to {minimum}.")

        except ValueError:
            print("Please enter a valid number.")


def calculate_configuration(
    data_size_gb,
    cluster_cpu_cores,
    cluster_memory_gb,
    workload
):
    driver_cores = min(2, cluster_cpu_cores)
    driver_memory = max(2, min(8, round(cluster_memory_gb * 0.1)))
    executor_cores = {"Light": 2, "Medium": 3, "Heavy": 4}[workload]
    available_cores = max(1, cluster_cpu_cores - driver_cores)
    executor_cores = min(executor_cores, available_cores)
    executors = max(1, available_cores // executor_cores)
    executor_memory = max(2, min(16, (cluster_memory_gb - driver_memory) // executors))
    total_executor_cores = executors * executor_cores
    return {
        "driver_cores": driver_cores,
        "driver_memory": driver_memory,
        "executors": executors,
        "executor_cores": executor_cores,
        "executor_memory": executor_memory,
        "input_partitions": max(1, round(data_size_gb / 0.128)),
        "shuffle_partitions": max(50, total_executor_cores * 10),
    }

 

  


def display_configuration(config):
    """Display the calculated Spark resource configuration."""

    print("\nSpark configuration")
    print("-------------------")
    for name, value in config.items():
        print(f"{name.replace('_', ' ').title():22}: {value}")
    print("\nSpark submit command")
    print("--------------------")
    print(
        "spark-submit --master yarn --deploy-mode cluster "
        f"--num-executors {config['executors']} "
        f"--executor-cores {config['executor_cores']} "
        f"--executor-memory {config['executor_memory']}G "
        f"--driver-cores {config['driver_cores']} "
        f"--driver-memory {config['driver_memory']}G "
        f"--conf spark.sql.shuffle.partitions={config['shuffle_partitions']} "
        "--conf spark.sql.adaptive.enabled=true stock_analysis.py"
    )


def main():

    data_size_gb = get_float("Input data size (GB): ")
    cpu_cores = get_int("Available CPU cores: ")
    memory_gb = get_int("Available memory (GB): ")
    choice = input("Workload [1=Light, 2=Medium, 3=Heavy]: ").strip()
    workload = {"1": "Light", "2": "Medium", "3": "Heavy"}.get(choice, "Medium")
    display_configuration(calculate_configuration(data_size_gb, cpu_cores, memory_gb, workload))


if __name__ == "__main__":
    main()
