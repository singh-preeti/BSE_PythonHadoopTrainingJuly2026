from pyspark.sql import SparkSession
from pyspark.sql.functions import window, sum, col

# ---------------------------------------------------------
# 1. START SPARK
# ---------------------------------------------------------

spark = SparkSession.builder \
    .appName("BeginnerStreamingTransactions") \
    .getOrCreate()

# ---------------------------------------------------------
# 2. READ TRANSACTIONS AS A STREAM
# ---------------------------------------------------------

schema = """
    trader_id INT,
    ticker STRING,
    transaction_type STRING,
    price DOUBLE,
    quantity INT,
    transaction_time TIMESTAMP
"""

transactions = spark.readStream \
    .schema(schema) \
    .option("header", True) \
    .csv("stream_transactions")

# ---------------------------------------------------------
# 3. WATERMARK + 5-MINUTE WINDOW
# ---------------------------------------------------------

result = transactions \
    .withWatermark("transaction_time", "10 minutes") \
    .groupBy(
        window("transaction_time", "5 minutes"),
        "ticker"
    ) \
    .agg(
        sum("quantity").alias("total_quantity"),
        sum(col("price") * col("quantity")).alias("total_value")
    )

# ---------------------------------------------------------
# 4. SHOW STREAMING RESULT
# ---------------------------------------------------------

query = result.writeStream \
    .outputMode("append") \
    .format("console") \
    .option("truncate", False) \
    .start()

print("Streaming started...")
print("Copy CSV files into the stream_transactions folder.")
print("Press Ctrl+C to stop.")

query.awaitTermination()
