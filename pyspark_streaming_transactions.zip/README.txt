BEGINNER PYSPARK STREAMING DEMO

Files:
- streaming_transactions.py
- day1_transactions.csv
- day2_transactions.csv
- day3_transactions.csv
- day4_transactions.csv
- day5_transactions.csv

SETUP:
1. Create a folder named stream_transactions.
2. Put the day-wise CSV files into it one at a time.
3. Run:
   spark-submit streaming_transactions.py

CONCEPTS:
- readStream = continuously watches for new files
- Micro-batch = Spark processes newly arrived files/data in small batches
- Watermark = allows late data for 10 minutes
- Window = groups transactions into 5-minute periods

IMPORTANT:
Keep the stream_transactions folder separate from the day-wise CSV files.
Copy day1 first, wait for Spark to process it, then copy day2, and so on.
