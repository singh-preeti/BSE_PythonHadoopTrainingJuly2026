#!/usr/bin/env python3
import sys

max_price = -1
trade = ""

for line in sys.stdin:
    _, value = line.strip().split("\t")
    price, tradeid = value.split(",")

    price = float(price)

    if price > max_price:
        max_price = price
        trade = tradeid

print("{}\t{}".format(trade, max_price))