#!/usr/bin/env python3
import sys

next(sys.stdin)

for line in sys.stdin:
    cols = line.strip().split(",")

    print("HIGH\t{},{}".format(cols[6], cols[0]))