# ---------------------------------------------
# BSE BANK - Reusable Ingestion Utility
# Phase 2 - Structured Logging + Exception Handling
# ---------------------------------------------

import logging

# ---------------------------------------------
# Configure Logging
# ---------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

# ---------------------------------------------
# Monday Transactions
# ---------------------------------------------
monday_transactions = [
    {"id": 101, "customer": "Rahul", "amount": 5000},
    {"id": 102, "customer": "Amit", "amount": 8000}
]

# ---------------------------------------------
# Tuesday Transactions
# (One Invalid Record)
# ---------------------------------------------
tuesday_transactions = [
    {"id": 201, "customer": "Neha", "amount": 3000},
    None,
    {"id": 202, "customer": "Priya", "amount": 4500}
]

# ---------------------------------------------
# Wednesday Transactions
# ---------------------------------------------
wednesday_transactions = [
    {"id": 301, "customer": "Rohit", "amount": 7000},
    {"id": 302, "customer": "Sneha", "amount": 2500}
]


# ---------------------------------------------
# Reusable Ingestion Utility
# ---------------------------------------------
def ingest_transactions(day_name, data):

    logging.info(f"Starting {day_name} Transaction Ingestion")

    for transaction in data:

        try:

            # Validate transaction
            if transaction is None:
                raise ValueError("Invalid Transaction Record")

            logging.info(transaction)

        except Exception as e:

            logging.error(e)

    logging.info(f"{day_name} Transaction Ingestion Completed")


# ---------------------------------------------
# Main Program
# ---------------------------------------------
ingest_transactions("Monday", monday_transactions)

ingest_transactions("Tuesday", tuesday_transactions)

ingest_transactions("Wednesday", wednesday_transactions)