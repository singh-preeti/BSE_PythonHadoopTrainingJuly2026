# ---------------------------------------------
# BSE BANK - List vs Generator Ingestion
# ---------------------------------------------

# ---------------------------------------------
# List-Based Transactions
# ---------------------------------------------
list_transactions = [
    {"id": 101, "customer": "Rahul", "amount": 5000},
    {"id": 102, "customer": "Amit", "amount": 8000},
    {"id": 103, "customer": "Neha", "amount": 3000}
]

# ---------------------------------------------
# Generator Function
# ---------------------------------------------
def transaction_generator():

    yield {"id": 201, "customer": "Priya", "amount": 6000}
    yield {"id": 202, "customer": "Rohit", "amount": 7000}
    yield {"id": 203, "customer": "Sneha", "amount": 4000}


# ---------------------------------------------
# Reusable Ingestion Utility
# ---------------------------------------------
def ingest_transactions(source_name, data):

    print(f"\nReading {source_name}...\n")

    for transaction in data:
        print(transaction)

    print(f"\n{source_name} Completed")


# ---------------------------------------------
# Main Program
# ---------------------------------------------
ingest_transactions("List Transactions", list_transactions)

ingest_transactions("Generator Transactions", transaction_generator())