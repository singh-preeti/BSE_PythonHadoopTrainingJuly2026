#create dictionary

customer = {
    "name": "",
    "balance": 0,
    "transactions": []
}


def create_account():
    customer["name"] = input("Enter Customer Name : ")
    print("Account Created Successfully")


def deposit():
    amount = float(input("Enter Deposit Amount : "))

    if amount <= 0:
        print("Invalid Deposit Amount")
        return

    customer["balance"] += amount
    customer["transactions"].append(amount)

    print("Amount Deposited")


def withdraw():
    amount = float(input("Enter Withdraw Amount : "))

    if amount <= 0:
        print("Negative Numbers Not Allowed")
        return

    if amount <= customer["balance"]:
        customer["balance"] -= amount
        customer["transactions"].append(-amount)
        print("Withdrawal Successful")
    else:
        print("Insufficient Balance")


def show_transactions():
    print("Transaction History")

    if len(customer["transactions"]) == 0:
        print("No Transactions Found")
        return

    for t in customer["transactions"]:
        if t > 0:
            print("Deposit :", t)
        else:
            print("Withdrawal :",(t))


def show_balance():
    print("Customer Name :", customer["name"])
    print("Current Balance :", customer["balance"])


while True:

    print("\nBSE BANK")
    print("1. Create Account")
    print("2. Deposit")
    print("3. Withdraw")
    print("4. Show Transactions")
    print("5. Show Balance")
    print("6. Exit")

    choice = int(input("Enter Choice : "))

    if choice == 1:
        create_account()

    elif choice == 2:
        deposit()

    elif choice == 3:
        withdraw()

    elif choice == 4:
        show_transactions()

    elif choice == 5:
        show_balance()

    elif choice == 6:
        print("Thank You for Using BSE BANK")
        break

    else:
        print("Invalid Choice")
