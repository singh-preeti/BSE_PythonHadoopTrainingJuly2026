# ---------------------------------------------
# BSE BANK - Reusable Ingestion Utility
# ---------------------------------------------

# Monday Transactions
monday_transactions = [
    {"id": 101, "customer": "Rahul", "amount": 5000},
    {"id": 102, "customer": "Amit", "amount": 8000}
]

# Tuesday Transactions
tuesday_transactions = [
    {"id": 201, "customer": "Neha", "amount": 3000},
    {"id": 202, "customer": "Priya", "amount": 4500}
]

# Wednesday Transactions
wednesday_transactions = [
    {"id": 301, "customer": "Rohit", "amount": 7000},
    {"id": 302, "customer": "Sneha", "amount": 2500}
]


# ---------------------------------------------
# Reusable Ingestion Utility
# ---------------------------------------------
def ingest_transactions(day_name, data):

    print(f"\nStarting {day_name} Transaction Ingestion...\n")

    for transaction in data:
        print(transaction)

    print(f"\n{day_name} Transaction Ingestion Completed.")


# ---------------------------------------------
# Main Program
# ---------------------------------------------
ingest_transactions("Monday", monday_transactions)

ingest_transactions("Tuesday", tuesday_transactions)

ingest_transactions("Wednesday", wednesday_transactions)