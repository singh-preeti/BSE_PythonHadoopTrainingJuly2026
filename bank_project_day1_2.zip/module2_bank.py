# ============================================
# BSE BANK - Large File Ingestion Pipeline
# ============================================

import time

print("=" * 60)
print("        BSE BANK - INGESTION PIPELINE")
print("=" * 60)

# -------------------------------------------------
# Step 1 : Sample Large Transaction File
# (Imagine this contains millions of records)
# -------------------------------------------------

transactions = [
    {"id": 101, "customer": "Rahul", "amount": 5000},
    {"id": 102, "customer": "Amit", "amount": -3000},
    {"id": 103, "customer": "Neha", "amount": 7000},
    {"id": 104, "customer": "Karan", "amount": None},
    {"id": 105, "customer": "Priya", "amount": 9000},
    {"id": 106, "customer": "Ankit", "amount": 0},
    {"id": 107, "customer": "Riya", "amount": 15000},
]


# -------------------------------------------------
# Step 2 : Generator (Reads one record at a time)
# -------------------------------------------------

def read_transactions(data):
    for transaction in data:
        yield transaction


# -------------------------------------------------
# Step 3 : Validation Function
# -------------------------------------------------

def is_valid(transaction):
    amount = transaction["amount"]

    if amount is None:
        return False

    if amount <= 0:
        return False

    return True


# -------------------------------------------------
# Step 4 : Ingestion Process
# -------------------------------------------------

valid_records = []
invalid_records = []

start_time = time.time()

for transaction in read_transactions(transactions):

    if is_valid(transaction):
        valid_records.append(transaction)
    else:
        invalid_records.append(transaction)

end_time = time.time()


# -------------------------------------------------
# Step 5 : Audit Report
# -------------------------------------------------

total_records = len(transactions)
valid_count = len(valid_records)
invalid_count = len(invalid_records)

print("\n")
print("=" * 60)
print("INGESTION AUDIT REPORT")
print("=" * 60)

print(f"Total Records     : {total_records}")
print(f"Valid Records     : {valid_count}")
print(f"Invalid Records   : {invalid_count}")
print(f"Processing Time   : {end_time - start_time:.4f} seconds")

print("\nValid Transactions")
print("-" * 40)

for record in valid_records:
    print(record)

print("\nInvalid Transactions")
print("-" * 40)

for record in invalid_records:
    print(record)

print("\n")
print("=" * 60)
print("INGESTION COMPLETED SUCCESSFULLY")
print("=" * 60)