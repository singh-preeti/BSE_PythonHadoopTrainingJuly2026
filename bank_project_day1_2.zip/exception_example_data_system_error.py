try:
    amount = int(input("Enter Deposit Amount: "))

    file = open("customers.txt")

    print("Deposit Successful:", amount)

except ValueError:
    print("Data Error: Amount should be numeric.")

except FileNotFoundError:
    print("System Error: Customer file is missing.")