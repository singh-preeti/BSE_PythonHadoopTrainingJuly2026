import logging

logging.basicConfig(
    filename="pipeline.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

transactions = [
    "1001,Rahul,500",
    "1002,Priya,1000",
    "1003,Amit,700"
]

logging.info("Pipeline Started")

for t in transactions:
    logging.info(f"Reading Record : {t}")

logging.info("All Records Processed")

print("Pipeline Completed")