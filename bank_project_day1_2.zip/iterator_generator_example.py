# -----------------------------------------
# LIST vs ITERATOR vs GENERATOR
# -----------------------------------------

print("===== LIST =====")

# List stores all values in memory
numbers = [1, 2, 3, 4, 5]

print(numbers)

print("\nReading List using for loop")
for number in numbers:
    print(number)


# -----------------------------------------
print("\n===== ITERATOR =====")

# Create an iterator from the list
iterator = iter(numbers)

print(next(iterator))
print(next(iterator))



# -----------------------------------------
print("\n===== GENERATOR =====")

# Generator creates values one by one
def generate_numbers():
    for i in range(1, 6):
        yield i

generator = generate_numbers()

print(next(generator))
print(next(generator))
print(next(generator))
