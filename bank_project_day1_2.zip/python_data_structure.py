# List
marks = [80, 90, 70, 90]
print("List:", marks)

# Tuple
dob = (10, "March", 2006)
print("Tuple:", dob)

# Set
cities = {"Mumbai", "Delhi", "Mumbai"}
print("Set:", cities)

# Dictionary
student = {
    "Name": "Rahul",
    "Age": 21
}
print("Dictionary:", student)
print("Student Name:", student["Age"])