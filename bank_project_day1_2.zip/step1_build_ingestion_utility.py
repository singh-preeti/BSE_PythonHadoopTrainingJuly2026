#Without Reusable Utility
# ---------------------------------------------
# BSE BANK - WITHOUT REUSABLE UTILITY
# ---------------------------------------------


print("BSE BANK - INGESTION WITHOUT REUSABLE UTILITY")


# ---------------------------------------------
# Transaction Records
# ---------------------------------------------
transactions = [
    {"id": 101, "customer": "Rahul", "amount": 5000},
    {"id": 102, "customer": "Amit", "amount": 8000},
    {"id": 103, "customer": "", "amount": 4000},
]

print("\nProcessing Transaction Records")

valid = []
invalid = []

for record in transactions:

    if record["customer"] != "" and record["amount"] > 0:
        valid.append(record)
    else:
        invalid.append(record)

print("Valid   :", len(valid))
print("Invalid :", len(invalid))


# ---------------------------------------------
# Customer Records
# ---------------------------------------------
customers = [
    {"id": 1, "customer": "Rahul", "amount": 1},
    {"id": 2, "customer": "", "amount": 1},
    {"id": 3, "customer": "Neha", "amount": 1},
]

print("\nProcessing Customer Records")

valid = []
invalid = []

for record in customers:

    if record["customer"] != "" and record["amount"] > 0:
        valid.append(record)
    else:
        invalid.append(record)

print("Valid   :", len(valid))
print("Invalid :", len(invalid))


# ---------------------------------------------
# Loan Records
# ---------------------------------------------
loans = [
    {"id": 201, "customer": "Amit", "amount": 500000},
    {"id": 202, "customer": "Riya", "amount": -10000},
    {"id": 203, "customer": "Neha", "amount": 250000},
]

print("\nProcessing Loan Records")

valid = []
invalid = []

for record in loans:

    if record["customer"] != "" and record["amount"] > 0:
        valid.append(record)
    else:
        invalid.append(record)

print("Valid   :", len(valid))
print("Invalid :", len(invalid))

# With Reusable Utility
# ---------------------------------------------
# BSE BANK - WITH REUSABLE UTILITY
# ---------------------------------------------

print("=" * 60)
print("BSE BANK - REUSABLE INGESTION UTILITY")
print("=" * 60)


# ---------------------------------------------
# Reusable Function
# ---------------------------------------------
def ingest_records(data, record_type):

    valid = []
    invalid = []

    print("\nProcessing", record_type)

    for record in data:

        if record["customer"] != "" and record["amount"] > 0:
            valid.append(record)
        else:
            invalid.append(record)

    print("Valid Records   :", len(valid))
    print("Invalid Records :", len(invalid))


# ---------------------------------------------
# Transaction Records
# ---------------------------------------------
transactions = [
    {"id": 101, "customer": "Rahul", "amount": 5000},
    {"id": 102, "customer": "Amit", "amount": 8000},
    {"id": 103, "customer": "", "amount": 4000},
]

# ---------------------------------------------
# Customer Records
# ---------------------------------------------
customers = [
    {"id": 1, "customer": "Rahul", "amount": 1},
    {"id": 2, "customer": "", "amount": 1},
    {"id": 3, "customer": "Neha", "amount": 1},
]

# ---------------------------------------------
# Loan Records
# ---------------------------------------------
loans = [
    {"id": 201, "customer": "Amit", "amount": 500000},
    {"id": 202, "customer": "Riya", "amount": -10000},
    {"id": 203, "customer": "Neha", "amount": 250000},
]


# ---------------------------------------------
# Same Function Used Everywhere
# ---------------------------------------------
ingest_records(transactions, "Transaction Records")

ingest_records(customers, "Customer Records")

ingest_records(loans, "Loan Records")