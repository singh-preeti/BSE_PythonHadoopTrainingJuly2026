import csv
import time

print("=" * 70)
print("      DIWALI SALES - LARGE FILE INGESTION PIPELINE")
print("=" * 70)

# ---------------------------------------------------------
# Input and Output Files
# ---------------------------------------------------------

INPUT_FILE = "Diwali Sales Data.csv"

VALID_FILE = "valid_sales.csv"

INVALID_FILE = "invalid_sales.csv"

AUDIT_FILE = "audit_report.txt"


# ---------------------------------------------------------
# Read Large File (Generator)
# Reads one row at a time
# ---------------------------------------------------------

def read_large_file(file_name):
 # encoding = "utf-8"
    with open(file_name, "r", encoding="latin1") as file:
 #DictReader converts each row into a dictionary.
        reader = csv.DictReader(file)

        for row in reader:
            #yield turns the function into a generator.
            yield row


# ---------------------------------------------------------
# Validate Record
# ---------------------------------------------------------

def validate_record(record):

    try:

        # Customer Name
        # strip() removes spaces from the beginning and end of a string.
        if record["Cust_name"].strip() == "":
            return False

        # Product
        if record["Product_ID"].strip() == "":
            return False

        # Orders
        orders = int(record["Orders"])

        if orders <= 0:
            return False

        # Amount
        amount = float(record["Amount"])

        if amount <= 0:
            return False

        return True

    except:
        return False


# ---------------------------------------------------------
# Save Record
# ---------------------------------------------------------

def save_record(file_name, record, header_written):

    with open(file_name, "a", newline="", encoding="utf-8") as file:

        writer = csv.DictWriter(file, fieldnames=record.keys())

        if not header_written:
            writer.writeheader()
            header_written = True

        writer.writerow(record)

    return header_written


# ---------------------------------------------------------
# Start Ingestion
# ---------------------------------------------------------

# Clear previous output files
open(VALID_FILE, "w").close()
open(INVALID_FILE, "w").close()

total_records = 0
valid_records = 0
invalid_records = 0

valid_header = False
invalid_header = False

start_time = time.time()

print("\nReading Large File...\n")

for record in read_large_file(INPUT_FILE):

    total_records += 1

    if validate_record(record):

        valid_records += 1

        valid_header = save_record(
            VALID_FILE,
            record,
            valid_header
        )

    else:

        invalid_records += 1

        invalid_header = save_record(
            INVALID_FILE,
            record,
            invalid_header
        )

    # Show progress every 1000 records
    if total_records % 1000 == 0:
        print(f"{total_records} records processed...")


end_time = time.time()

processing_time = round(end_time - start_time, 2)


# ---------------------------------------------------------
# Audit Report
# ---------------------------------------------------------

success_rate = (valid_records / total_records) * 100

with open(AUDIT_FILE, "w") as report:

    report.write("=" * 50 + "\n")
    report.write("DIWALI SALES INGESTION AUDIT REPORT\n")
    report.write("=" * 50 + "\n\n")

    report.write(f"Input File       : {INPUT_FILE}\n")
    report.write(f"Total Records    : {total_records}\n")
    report.write(f"Valid Records    : {valid_records}\n")
    report.write(f"Invalid Records  : {invalid_records}\n")
    report.write(f"Success Rate     : {success_rate:.2f}%\n")
    report.write(f"Processing Time  : {processing_time} seconds\n")


# ---------------------------------------------------------
# Summary
# ---------------------------------------------------------

print("\n")
print("=" * 60)
print("INGESTION SUMMARY")
print("=" * 60)

print("Input File      :", INPUT_FILE)
print("Total Records   :", total_records)
print("Valid Records   :", valid_records)
print("Invalid Records :", invalid_records)
print("Success Rate    :", round(success_rate, 2), "%")
print("Processing Time :", processing_time, "seconds")

print("\nGenerated Files")
print("-------------------------")
print("valid_sales.csv")
print("invalid_sales.csv")
print("audit_report.txt")

print("\nLarge File Ingestion Completed Successfully.")