DATABASE="data/customers.db"
OUTPUT_FILE="output/customers.csv"
CHECKPOINT_FILE="checkpoint/checkpoint.txt"
MAX_RETRY=3
