import sqlite3
from config import DATABASE

def fetch_new_records(last_id):
 conn=sqlite3.connect(DATABASE);
 c=conn.cursor();
 c.execute("SELECT * FROM customers WHERE id>?",(last_id,));

 row=c.fetchall();
 conn.close();
 return row
