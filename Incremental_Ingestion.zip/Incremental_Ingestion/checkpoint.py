import os
from config import CHECKPOINT_FILE

def get_last_id():
    if not os.path.exists(CHECKPOINT_FILE): return 0
    with open(CHECKPOINT_FILE) as f: return int(f.read())

def save_last_id(id):
    with open(CHECKPOINT_FILE,"w") as f:f.write(str(id))
