import time
import traceback
from logger import logger

def retry(operation, max_retry):
    attempts = 0

    while attempts < max_retry:
        try:
            operation()
            return

        except Exception as e:
            attempts += 1

            logger.error(e)

            print(f"\nRetry {attempts}")
            print("Actual Error:")
            traceback.print_exc()

            time.sleep(2)

    raise Exception("Maximum Retry Reached")