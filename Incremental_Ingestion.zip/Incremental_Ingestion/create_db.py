import sqlite3,os
os.makedirs("data",exist_ok=True)


conn=sqlite3.connect("data/customers.db");
cursor =conn.cursor();
cursor.execute("CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY,name TEXT,city TEXT,salary REAL)")
rows=[(1,"Rahul","Mumbai",45000),(2,"Sneha","Pune",52000),(3,"Amit","Delhi",70000),(4,"Priya","Bangalore",61000),(5,"Karan","Hyderabad",47000), (7,"Amit","Mumbai",47000)]
cursor.executemany("INSERT OR IGNORE INTO customers VALUES(?,?,?,?)",rows);
conn.commit();

conn.close();
print("DB created")