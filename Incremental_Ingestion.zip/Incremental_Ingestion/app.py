import csv,os
from database import fetch_new_records
from checkpoint import *
from transform import transform
from retry import retry
from config import *
from logger import logger

def pipeline():
 last_id=get_last_id();

 print("Last Processed:",last_id);

 records=fetch_new_records(last_id)

 if not records:print("No New Records"); return

 data = transform(records);

 tmp=OUTPUT_FILE+".tmp";

 highest = last_id
 try:
  with open(tmp,"w",newline="") as f:

   w=csv.writer(f);

   w.writerow(["ID","NAME","CITY","SALARY","CATEGORY"])

   for r in data:
       w.writerow(r);

       highest=r[0]

  os.replace(tmp,OUTPUT_FILE);save_last_id(highest);

  logger.info("Pipeline Success");
  print("Pipeline Completed")
 except Exception as e:
  logger.error(e)

  if os.path.exists(tmp):os.remove(tmp)
  print("Rollback Completed")

retry(pipeline,MAX_RETRY)
