def transform(records):
 t=[]
 for id,name,city,salary in records:
     t.append([id,name.upper(),city.title(),salary,"HIGH" if salary>50000 else "LOW"])
 return t
