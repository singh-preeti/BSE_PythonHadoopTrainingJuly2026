def validate_quantity(quantity):

    return quantity > 0


def validate_price(price):

    return price > 0


def validate_trade_id(trade_id):

    return trade_id != ""