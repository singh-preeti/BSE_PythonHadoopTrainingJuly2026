# ingestion.py

import pandas as pd
from logger import logger



def load_trade_file(file_name):
    """
    Reads one stock market trade file.
    """

    logger.info(f"Reading {file_name}")

    df = pd.read_csv(file_name)

    print(f"{file_name} Loaded : {len(df)} Trades")

    return df