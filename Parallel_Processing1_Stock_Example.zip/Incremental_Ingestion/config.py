DATABASE="data/customers.db"
OUTPUT_FILE="output/customers.csv"
CHECKPOINT_FILE="checkpoint/checkpoint.txt"
MAX_RETRY=3
TRADE_FILES = [
    "data/trade_day1.csv",
    "data/trade_day2.csv",
    "data/trade_day3.csv"
]