from multiprocessing import Pool
import pandas as pd

from ingestion import load_trade_file


def load_all_trade_files(files):

    with Pool(processes=3) as pool:

        dataframes = pool.map(load_trade_file, files)

    final_df = pd.concat(dataframes, ignore_index=True)

    print("\nTotal Records :", len(final_df))

    return final_df