import csv
import os

from checkpoint import get_last_id, save_last_id
from transform import transform
from retry import retry
from config import *
from logger import logger
from parallel_loader import load_all_trade_files


def pipeline():

    logger.info("========== STOCK MARKET INGESTION STARTED ==========")

    last_trade_id = int(get_last_id())

    print("Last Processed :", last_trade_id)

    # Read all files
    df = load_all_trade_files(TRADE_FILES)

    # Convert Trade_ID to integer
    df["Trade_ID"] = df["Trade_ID"].astype(int)

    # Incremental records
    new_records = df[df["Trade_ID"] > last_trade_id]

    if new_records.empty:
        print("No New Trade Records")
        logger.info("No New Trade Records")
        return

    records = new_records.values.tolist()

    processed = transform(records)

    temp = OUTPUT_FILE + ".tmp"

    highest = last_trade_id

    try:

        with open(temp, "w", newline="") as file:

            writer = csv.writer(file)

            writer.writerow([
                "Trade_ID",
                "Investor_ID",
                "Trade_Date",
                "ISIN",
                "Security",
                "Action",
                "Quantity",
                "Price",
                "Trade_Value",
                "Category"
            ])

            for row in processed:

                writer.writerow(row)

                highest = row[0]

        os.replace(temp, OUTPUT_FILE)

        save_last_id(highest)

        logger.info("Pipeline Completed Successfully")

        print("Pipeline Completed Successfully")

    except Exception as e:

        logger.error(str(e))

        if os.path.exists(temp):
            os.remove(temp)

        print("Rollback Completed")


if __name__ == "__main__":
    retry(pipeline, MAX_RETRY)