#python -m unittest discover tests
import unittest

from ingestion import load_trade_file


class TestIngestion(unittest.TestCase):

    def test_file_load(self):

        df = load_trade_file("data/trade_day5.csv")

        self.assertGreater(len(df), 0)

    def test_columns(self):

        df = load_trade_file("data/trade_day1.csv")

        self.assertIn("Trade_ID", df.columns)

        self.assertIn("Price", df.columns)

        self.assertIn("Quantity", df.columns)


if __name__ == "__main__":
    unittest.main()