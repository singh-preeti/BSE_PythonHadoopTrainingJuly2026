import unittest

from validator import *


class TestValidation(unittest.TestCase):

    def test_valid_quantity(self):

        self.assertTrue(validate_quantity(100))

    def test_invalid_quantity(self):

        self.assertFalse(validate_quantity(-50))

    def test_valid_price(self):

        self.assertTrue(validate_price(2500))

    def test_invalid_price(self):

        self.assertFalse(validate_price(-1))

    def test_trade_id(self):

        self.assertTrue(validate_trade_id("TR1001"))

    def test_blank_trade(self):

        self.assertFalse(validate_trade_id(""))


if __name__ == "__main__":
    unittest.main()