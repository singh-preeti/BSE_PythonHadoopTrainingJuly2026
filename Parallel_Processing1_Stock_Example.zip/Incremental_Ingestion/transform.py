def transform(records):

    output = []

    for row in records:

        trade_id = row[0]
        investor = row[1]
        trade_date = row[2]
        isin = row[3]
        security = row[4]
        action = row[5]
        quantity = int(row[6])
        price = float(row[7])

        trade_value = quantity * price

        if trade_value >= 500000:
            category = "HIGH VALUE"
        elif trade_value >= 100000:
            category = "MEDIUM VALUE"
        else:
            category = "LOW VALUE"

        output.append([
            trade_id,
            investor,
            trade_date,
            isin,
            security,
            action,
            quantity,
            price,
            trade_value,
            category
        ])

    return output